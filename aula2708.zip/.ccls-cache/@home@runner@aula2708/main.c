#include <stdio.h>

int main() 
{
  int x;
  printf("informe um numero inteiro: ");
  scanf("%d", &x);
  if(x % 2==0)
    printf("%d é par", x);
  else
    printf("%d é impar", x);
  return 0;
}